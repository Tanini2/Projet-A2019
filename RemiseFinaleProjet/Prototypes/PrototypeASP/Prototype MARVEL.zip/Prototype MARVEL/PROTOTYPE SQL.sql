CREATE DATABASE MARLVEL_PROTOTYPE

CREATE TABLE tbljoueur
(
noUser int not null IDENTITY(1,1) PRIMARY KEY,
nomJoueur varchar(50) not null,

);

CREATE TABLE tblcategorie
(
noCategorie int not null IDENTITY(1,1) PRIMARY KEY,
nomCategorie varchar(50) not null,

);

CREATE TABLE tblcategoriejoueur
(
noUser int not null,
noCategorie int not null, 
score int not null,
FOREIGN KEY (noUser) REFERENCES tbljoueur(noUser),
FOREIGN KEY (noCategorie) REFERENCES tblcategorie(noCategorie),
Primary key (noUser,noCategorie)
);

﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApplication3.Models
{
    public partial class Marvel_PrototypeContext : DbContext
    {
        public Marvel_PrototypeContext()
        {
        }

        public Marvel_PrototypeContext(DbContextOptions<Marvel_PrototypeContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Tblcategorie> Tblcategorie { get; set; }
        public virtual DbSet<Tblcategoriejoueur> Tblcategoriejoueur { get; set; }
        public virtual DbSet<Tbljoueur> Tbljoueur { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=Marvel_Prototype;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tblcategorie>(entity =>
            {
                entity.HasKey(e => e.NoCategorie);

                entity.ToTable("tblcategorie");

                entity.Property(e => e.NoCategorie).HasColumnName("noCategorie");

                entity.Property(e => e.NomCategorie)
                    .IsRequired()
                    .HasColumnName("nomCategorie")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tblcategoriejoueur>(entity =>
            {
                entity.HasKey(e => new { e.NoUser, e.NoCategorie });

                entity.ToTable("tblcategoriejoueur");

                entity.Property(e => e.NoUser).HasColumnName("noUser");

                entity.Property(e => e.NoCategorie).HasColumnName("noCategorie");

                entity.Property(e => e.Score).HasColumnName("score");

                entity.HasOne(d => d.NoCategorieNavigation)
                    .WithMany(p => p.Tblcategoriejoueur)
                    .HasForeignKey(d => d.NoCategorie)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tblcatego__noCat__286302EC");

                entity.HasOne(d => d.NoUserNavigation)
                    .WithMany(p => p.Tblcategoriejoueur)
                    .HasForeignKey(d => d.NoUser)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tblcatego__noUse__276EDEB3");
            });

            modelBuilder.Entity<Tbljoueur>(entity =>
            {
                entity.HasKey(e => e.NoUser);

                entity.ToTable("tbljoueur");

                entity.Property(e => e.NoUser).HasColumnName("noUser");

                entity.Property(e => e.NomJoueur)
                    .IsRequired()
                    .HasColumnName("nomJoueur")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }
    }
}

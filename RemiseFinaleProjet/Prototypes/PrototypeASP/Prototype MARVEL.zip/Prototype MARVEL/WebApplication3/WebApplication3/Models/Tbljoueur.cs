﻿using System;
using System.Collections.Generic;

namespace WebApplication3.Models
{
    public partial class Tbljoueur
    {
        public Tbljoueur()
        {
            Tblcategoriejoueur = new HashSet<Tblcategoriejoueur>();
        }

        public int NoUser { get; set; }
        public string NomJoueur { get; set; }

        public ICollection<Tblcategoriejoueur> Tblcategoriejoueur { get; set; }
    }
}

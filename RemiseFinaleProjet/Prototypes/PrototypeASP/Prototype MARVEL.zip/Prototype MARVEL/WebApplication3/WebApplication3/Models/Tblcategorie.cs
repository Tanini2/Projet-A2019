﻿using System;
using System.Collections.Generic;

namespace WebApplication3.Models
{
    public partial class Tblcategorie
    {
        public Tblcategorie()
        {
            Tblcategoriejoueur = new HashSet<Tblcategoriejoueur>();
        }

        public int NoCategorie { get; set; }
        public string NomCategorie { get; set; }

        public ICollection<Tblcategoriejoueur> Tblcategoriejoueur { get; set; }
    }
}

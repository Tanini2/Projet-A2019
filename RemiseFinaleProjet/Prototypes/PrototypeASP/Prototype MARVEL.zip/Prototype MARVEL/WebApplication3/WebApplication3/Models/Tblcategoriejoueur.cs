﻿using System;
using System.Collections.Generic;

namespace WebApplication3.Models
{
    public partial class Tblcategoriejoueur
    {
        public int NoUser { get; set; }
        public int NoCategorie { get; set; }
        public int Score { get; set; }

        public Tblcategorie NoCategorieNavigation { get; set; }
        public Tbljoueur NoUserNavigation { get; set; }
    }
}

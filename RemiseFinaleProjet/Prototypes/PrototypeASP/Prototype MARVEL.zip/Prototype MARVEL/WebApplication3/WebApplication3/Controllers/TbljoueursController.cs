﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class TbljoueursController : Controller
    {
        private readonly Marvel_PrototypeContext _context;

        public TbljoueursController(Marvel_PrototypeContext context)
        {
            _context = context;
        }

        // GET: Tbljoueurs
        public async Task<IActionResult> Index()
        {
            return View(await _context.Tbljoueur.ToListAsync());
        }

        // GET: Tbljoueurs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tbljoueur = await _context.Tbljoueur
                .FirstOrDefaultAsync(m => m.NoUser == id);
            if (tbljoueur == null)
            {
                return NotFound();
            }

            return View(tbljoueur);
        }

        // GET: Tbljoueurs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tbljoueurs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NoUser,NomJoueur")] Tbljoueur tbljoueur)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tbljoueur);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tbljoueur);
        }

        // GET: Tbljoueurs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tbljoueur = await _context.Tbljoueur.FindAsync(id);
            if (tbljoueur == null)
            {
                return NotFound();
            }
            return View(tbljoueur);
        }

        // POST: Tbljoueurs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NoUser,NomJoueur")] Tbljoueur tbljoueur)
        {
            if (id != tbljoueur.NoUser)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tbljoueur);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TbljoueurExists(tbljoueur.NoUser))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tbljoueur);
        }

        // GET: Tbljoueurs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tbljoueur = await _context.Tbljoueur
                .FirstOrDefaultAsync(m => m.NoUser == id);
            if (tbljoueur == null)
            {
                return NotFound();
            }

            return View(tbljoueur);
        }

        // POST: Tbljoueurs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tbljoueur = await _context.Tbljoueur.FindAsync(id);
            _context.Tbljoueur.Remove(tbljoueur);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TbljoueurExists(int id)
        {
            return _context.Tbljoueur.Any(e => e.NoUser == id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class TblcategoriejoueursController : Controller
    {
        private readonly Marvel_PrototypeContext _context;

        public TblcategoriejoueursController(Marvel_PrototypeContext context)
        {
            _context = context;
        }

        // GET: Tblcategoriejoueurs
        public async Task<IActionResult> Index()
        {
            var marvel_PrototypeContext = _context.Tblcategoriejoueur.Include(t => t.NoCategorieNavigation).Include(t => t.NoUserNavigation);
            return View(await marvel_PrototypeContext.ToListAsync());
        }

        // GET: Tblcategoriejoueurs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategoriejoueur = await _context.Tblcategoriejoueur
                .Include(t => t.NoCategorieNavigation)
                .Include(t => t.NoUserNavigation)
                .FirstOrDefaultAsync(m => m.NoUser == id);
            if (tblcategoriejoueur == null)
            {
                return NotFound();
            }

            return View(tblcategoriejoueur);
        }

        // GET: Tblcategoriejoueurs/Create
        public IActionResult Create()
        {
            ViewData["NoCategorie"] = new SelectList(_context.Tblcategorie, "NoCategorie", "NomCategorie");
            ViewData["NoUser"] = new SelectList(_context.Tbljoueur, "NoUser", "NomJoueur");
            return View();
        }

        // POST: Tblcategoriejoueurs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NoUser,NoCategorie,Score")] Tblcategoriejoueur tblcategoriejoueur)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tblcategoriejoueur);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["NoCategorie"] = new SelectList(_context.Tblcategorie, "NoCategorie", "NomCategorie", tblcategoriejoueur.NoCategorie);
            ViewData["NoUser"] = new SelectList(_context.Tbljoueur, "NoUser", "NomJoueur", tblcategoriejoueur.NoUser);
            return View(tblcategoriejoueur);
        }

        // GET: Tblcategoriejoueurs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategoriejoueur = await _context.Tblcategoriejoueur.FindAsync(id);
            if (tblcategoriejoueur == null)
            {
                return NotFound();
            }
            ViewData["NoCategorie"] = new SelectList(_context.Tblcategorie, "NoCategorie", "NomCategorie", tblcategoriejoueur.NoCategorie);
            ViewData["NoUser"] = new SelectList(_context.Tbljoueur, "NoUser", "NomJoueur", tblcategoriejoueur.NoUser);
            return View(tblcategoriejoueur);
        }

        // POST: Tblcategoriejoueurs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NoUser,NoCategorie,Score")] Tblcategoriejoueur tblcategoriejoueur)
        {
            if (id != tblcategoriejoueur.NoUser)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tblcategoriejoueur);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblcategoriejoueurExists(tblcategoriejoueur.NoUser))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["NoCategorie"] = new SelectList(_context.Tblcategorie, "NoCategorie", "NomCategorie", tblcategoriejoueur.NoCategorie);
            ViewData["NoUser"] = new SelectList(_context.Tbljoueur, "NoUser", "NomJoueur", tblcategoriejoueur.NoUser);
            return View(tblcategoriejoueur);
        }

        // GET: Tblcategoriejoueurs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategoriejoueur = await _context.Tblcategoriejoueur
                .Include(t => t.NoCategorieNavigation)
                .Include(t => t.NoUserNavigation)
                .FirstOrDefaultAsync(m => m.NoUser == id);
            if (tblcategoriejoueur == null)
            {
                return NotFound();
            }

            return View(tblcategoriejoueur);
        }

        // POST: Tblcategoriejoueurs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tblcategoriejoueur = await _context.Tblcategoriejoueur.FindAsync(id);
            _context.Tblcategoriejoueur.Remove(tblcategoriejoueur);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TblcategoriejoueurExists(int id)
        {
            return _context.Tblcategoriejoueur.Any(e => e.NoUser == id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class TblcategoriesController : Controller
    {
        private readonly Marvel_PrototypeContext _context;

        public TblcategoriesController(Marvel_PrototypeContext context)
        {
            _context = context;
        }

        // GET: Tblcategories
        public async Task<IActionResult> Index()
        {
            return View(await _context.Tblcategorie.ToListAsync());
        }

        // GET: Tblcategories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategorie = await _context.Tblcategorie
                .FirstOrDefaultAsync(m => m.NoCategorie == id);
            if (tblcategorie == null)
            {
                return NotFound();
            }

            return View(tblcategorie);
        }

        // GET: Tblcategories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tblcategories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NoCategorie,NomCategorie")] Tblcategorie tblcategorie)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tblcategorie);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tblcategorie);
        }

        // GET: Tblcategories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategorie = await _context.Tblcategorie.FindAsync(id);
            if (tblcategorie == null)
            {
                return NotFound();
            }
            return View(tblcategorie);
        }

        // POST: Tblcategories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NoCategorie,NomCategorie")] Tblcategorie tblcategorie)
        {
            if (id != tblcategorie.NoCategorie)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tblcategorie);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TblcategorieExists(tblcategorie.NoCategorie))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tblcategorie);
        }

        // GET: Tblcategories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblcategorie = await _context.Tblcategorie
                .FirstOrDefaultAsync(m => m.NoCategorie == id);
            if (tblcategorie == null)
            {
                return NotFound();
            }

            return View(tblcategorie);
        }

        // POST: Tblcategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tblcategorie = await _context.Tblcategorie.FindAsync(id);
            _context.Tblcategorie.Remove(tblcategorie);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TblcategorieExists(int id)
        {
            return _context.Tblcategorie.Any(e => e.NoCategorie == id);
        }
    }
}

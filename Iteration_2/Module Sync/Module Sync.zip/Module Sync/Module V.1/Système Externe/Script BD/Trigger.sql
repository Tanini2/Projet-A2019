USE cegepjon_p2019-dev;
GO

DROP TRIGGER IF EXISTS insertLog;
DELIMITER $$
CREATE TRIGGER insertLog AFTER INSERT ON Etudiant
	FOR EACH ROW
		BEGIN
			INSERT INTO modificationLog VALUES ("Etudiant", "INSERT", NOW(), 0, NULL, CONCAT_WS("|", NEW.codePermanent, NEW.nom, NEW.prenom, NEW.dateNaissance, NEW.adresseMail));
		END; $$
		
DROP TRIGGER IF EXISTS updateLog;

DELIMITER $$
CREATE TRIGGER updateLog AFTER UPDATE ON Etudiant
	FOR EACH ROW
		BEGIN
			INSERT INTO modificationLog VALUES ("Etudiant", "UPDATE", NOW(), 0, NULL, CONCAT_WS("|", NEW.codePermanent, NEW.nom, NEW.prenom, NEW.dateNaissance, NEW.adresseMail));
		END; $$
		
DELIMITER $$
CREATE TRIGGER DeleteLog AFTER DELETE ON Etudiant
	FOR EACH ROW
		BEGIN
			INSERT INTO modificationLog VALUES ("Etudiant", "DELETE", NOW(), 0, NULL, CONCAT_WS("|", NEW.codePermanent, NEW.nom, NEW.prenom, NEW.dateNaissance, NEW.adresseMail));
		END; $$
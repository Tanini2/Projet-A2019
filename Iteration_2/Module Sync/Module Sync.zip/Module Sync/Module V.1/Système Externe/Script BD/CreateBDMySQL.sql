USE cegepjon_p2019-dev;
GO

DROP TABLE IF EXISTS Etudiant;
CREATE TABLE Etudiant (
	codePermanent		varchar(12)		NOT NULL,
	nom					varchar(50)		NOT NULL,
	prenom				varchar(50)		NOT NULL,
	dateNaissance		date			NOT NULL,
	adresseMail			varchar(60)		NOT NULL,
	PRIMARY KEY(codePermanent)
) ENGINE=INNODB;

DROP TABLE IF EXISTS ModificationLog;
CREATE TABLE ModificationLog (
	logId				int(11)			NOT NULL 	AUTO_INCREMENT,
	nomTable			varchar(20)		NOT NULL,
	typeRequete			varchar(10)		NOT NULL,
	dateEntree			datetime		NOT NULL,
	validationRequete	bit(1)			NOT NULL,
	oldEntry			text			NOT NULL,
	newEntry			text			NOT NULL,
	PRIMARY KEY(logId)
) ENGINE=INNODB;
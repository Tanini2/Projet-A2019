<?php

//Informations du serveur
$servername = "dicj.info";
$username = "cegepjon_p2019";
$password = "ProjFGH19!";
$database = "cegepjon_p2019-dev";

$json = file_get_contents('php://input');
$requete = json_decode($json);

$total = count((array)$requete);

for($i = 0; $i < $total; $i++){
	$systemSource = $requete[$i]->systemSource;
	$systemDestination = $requete[$i]->systemDestination;
	$table = $requete[$i]->table;
	$typeRequete = $requete[$i]->typeRequete;
	$codePermanent = $requete[$i]->entree->codePermanant;
	$nom = $requete[$i]->entree->nom;
	$prenom = $requete[$i]->entree->prenom;
	$dateNaissance = str_replace("/", "", $requete[$i]->entree->dateNaissance);
	$dateNaissance =  strtotime($dateNaissance);
	$adresseMail = $requete[$i]->entree->adresseMail;

	$typeRequete = strtoupper($typeRequete);
	
 //Cr�er un objet connection
	$conn = new mysqli($servername, $username, $password, $database);
	//Si une erreur, ferme la connexion
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	
	if($typeRequete == "INSERT"){
		$sql = "INSERT INTO ".$table." VALUES ('$codePermanent', '$nom', '$prenom', '$dateNaissance', '$adresseMail')";
		if(mysqli_query($conn, $sql)){ 
			echo "INSERT OK";
            ?> <br /> <?php
            echo $sql;
		} else { 
			echo "ERREUR INSERT";
			?> <br /> <?php
            echo $sql;
		} 
	}
	else if($typeRequete == "UPDATE"){
		$sql = $typeRequete." ".$table." SET nom='$nom' prenom='$prenom' dateNaissance='$dateNaissance' adresseMail='$adresseMail' WHERE codePermanent='$codePermanent'";
		if(mysqli_query($conn, $sql)){ 
			echo "UPDATE OK";
            ?> <br /> <?php
            echo $sql;
		} else { 
			echo "ERREUR UPDATE";
            ?> <br /> <?php
            echo $sql;
		} 
	}

	mysqli_close($conn);
};

//Créer un objet connection

$conn = new mysqli($servername, $username, $password, $database);

//Si une erreur, ferme la connexion

if ($conn->connect_error) 

{

	die("Connection failed: " . $conn->connect_error);

}



$sql = "DELETE FROM ModificationLog";

if ($conn->query($sql) === TRUE) {

    echo "New record in modification log";

} else {

    echo "Error: " . $sql . "<br>" . $conn->error;

}



$conn->close();

?>
<?php

class ModificationLog
{

	public $logId;
    public $nomTable;
    public $typeRequete;
    public $dateEntree;
    public $validationRequete;
    public $oldEntry;
    public $newEntry;

    public function __construct()
    {

    }

    public function ModificationLog($Id, $Table, $Requete, $dateTime, $validRequete, $oEntry, $nEntry){
		$this->logId = $Id;
		$this->nomTable = $Table;
		$this->typeRequete = $Requete;
		$this->dateEntree = $dateTime;
		$this->validationRequete = $validRequete;
		$this->oldEntry = $oEntry;
		$this->newEntry = $nEntry;
	}
	
    public function GetLogId(){
		return $this->logId;
	}
	
	public function GetNomTable(){
		return $this->nomTable;
	}
	
	public function GetTypeRequest(){
		return $this->typeRequete;
	}
	
	public function GetValidationRequete(){
		return $this->validationRequete;
	}
	
	public function GetDateEntree(){
		return $this->dateEntree;
	}
	
	public function GetOldEntry(){
		return $this->oldEntry;
	}
	
	public function GetNewEntry(){
		return $this->newEntry;
	}

	public function SetLogId($logId){
        $this->logId = $logId;
    }
	
	public function SetNomTable($Tables){
		$this->nomtable = $Tables;
	}
	
	public function SetTypeRequest($Requete){
		$this->typeRequete = $Requete;
	}
	
	public function SetValidationRequete($validRequete){
		$this->validationRequete = $validRequete;
	}

	public function SetDateEntree($dateEntree){
        $this->dateEntree = $dateEntree;
    }
    public function SetOldEntry($oldEntry){
	    $this->oldEntry = $oldEntry;
    }
    public function SetNewEntry($newEntry){
	    $this->newEntry = $newEntry;
    }
}

//Informations du serveur
$servername = "dicj.info";
$username = "cegepjon_p2019";
$password = "ProjFGH19!";
$database = "cegepjon_p2019-dev";
//Créer un objet connection
$conn = new mysqli($servername, $username, $password, $database);
//Si une erreur, ferme la connexion
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
//REQUÊTE
$tblLog = Array();

$sql = "SELECT logId, nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry
		FROM ModificationLog";
//Prépare la query
$stmt = $conn->query($sql);


if ($stmt->num_rows > 0) {
	//Passe à travers tous les résultats


	while($row = $stmt->fetch_assoc()){
        //var_dump($row);
		$class = new ModificationLog();
		//On met les données dans un tableau temporaire
		$class->SetLogId($row['logId']);
		$class->SetNomTable(utf8_encode($row['nomTable']));
		$class->SetTypeRequest(utf8_encode($row['typeRequete']));
		$class->SetDateEntree($row['dateEntree']);
		$class->SetValidationRequete($row['validationRequete']);
		$class->SetOldEntry(utf8_encode($row['oldEntry']));
		$class->SetNewEntry(utf8_encode($row['newEntry']));
        //var_dump($class);
		$tblLog[] = $class;
	}
	//var_dump($tblLog);
	//echo utf8_encode($row['nomTable']);
	//echo $row['nomTable'];
}
echo json_encode($tblLog);

?>
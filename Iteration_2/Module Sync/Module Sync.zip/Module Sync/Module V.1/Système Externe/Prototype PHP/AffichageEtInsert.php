<?php

echo 'Entrées de la table tblUser';

?><br /><?php

include 'SelectUsers.php';?>

<br />

<form action="./InsertData.php" method="post">

	Code Permanent : <br>

	<input type="text" name="codeP"><br>

	Nom : <br>

	<input type="text" name="lastname"><br>

	Prénom : <br>

	<input type="text" name="firstname"><br>

	Date de Naissance:<br>

	<input type="datetime" name="dateNaissance"><br><br>

	Adresse Mail:<br>

	<input type="text" name="adresseMail"><br><br>

	<input type="submit" value="Submit">

</form>
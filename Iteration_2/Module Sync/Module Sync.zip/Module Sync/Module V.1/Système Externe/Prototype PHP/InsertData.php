<?php

//Informations du serveur

$servername = "dicj.info";

$username = "cegepjon_p2019";

$password = "ProjFGH19!";

$database = "cegepjon_p2019-dev";





$codeP = $_POST['codeP'];

$nom = $_POST['lastname'];

$prenom = $_POST['firstname'];

$date = $_POST['dateNaissance'];

$adresseMail = $_POST['adresseMail'];



//Créer un objet connection

$conn = new mysqli($servername, $username, $password, $database);

//Si une erreur, ferme la connexion

if ($conn->connect_error) 

{

	die("Connection failed: " . $conn->connect_error);

}



$sql = "INSERT INTO Etudiant VALUES ('$codeP', '$nom', '$prenom', '$date', '$adresseMail')";

if ($conn->query($sql) === TRUE) {

    echo "New record created successfully";

} else {

    echo "Error: " . $sql . "<br>" . $conn->error;

}



$conn->close();

//Créer un objet connection

$conn = new mysqli($servername, $username, $password, $database);

//Si une erreur, ferme la connexion

if ($conn->connect_error) 

{

	die("Connection failed: " . $conn->connect_error);

}



$sql = "INSERT INTO ModificationLog (nomTable,typeRequete,dateEntree,validationRequete,oldEntry,newEntry) VALUES ('Etudiant', 'INSERT', NOW(), 1, '', '$codeP|$nom|$prenom|$date|$adresseMail')";

if ($conn->query($sql) === TRUE) {

    echo "New record in modification log";

} else {

    echo "Error: " . $sql . "<br>" . $conn->error;

}



$conn->close();

?>
<?php
//Informations du serveur
$servername = "dicj.info";
$username = "cegepjon_p2019";
$password = "ProjFGH19!";
$database = "cegepjon_p2019-dev";

$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error)
{
	die("Connection failed: ".$conn->connect_error);
}

$Infos = array();
$sql = "SELECT *
		FROM Etudiant";
$stmt = $conn->query($sql);
if($stmt->num_rows > 0){
	while($row = $stmt->fetch_assoc()){
		$temp = [
			'codePermanent'=>$row['codePermanent'],
			'nom'=>utf8_encode($row['nom']),
			'prenom'=>utf8_encode($row['prenom']),
			'dateNaissance'=>$row['dateNaissance'],
			'adresseMail'=>utf8_encode($row['adresseMail'])
		];
		array_push($Infos, $temp);
	}
}
echo json_encode($Infos,JSON_UNESCAPED_UNICODE);
mysqli_free_result($stmt);
?>
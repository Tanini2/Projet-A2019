﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using marvel_sync.Models;
using marvel_sync.Externe;
using marvel_sync.Interne;
using System.Reflection;

namespace marvel_sync
{
    class Comparateur
    {
        List<ModificationLog> internalModification;
        List<ModificationLog> externalModification;



        List<Requete> request;

        public Comparateur(SystemExterne externe, SystemInterne interne)
        {
            foreach (ModificationLog log in interne.GetModificationLog())
            {
                var type = Type.GetType("marvel_sync.Models." + log.nomTable);
                object data = Activator.CreateInstance(type, log.newEntry);

                Requete requete = new Requete("EXTERNAL", "INTERNAL", log.nomTable, log.typeRequete, data);
                externe.AddLogRequest(requete);
                //    object data = Assembly.GetExecutingAssembly().CreateInstance("marvel_sync.Models." + log.nomTable);
                //    string[] split = log.newEntry.Split('|');
                //    PropertyInfo[] properties = data.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

                //    for(int cpt = 0; cpt < properties.Length; cpt++)
                //    {
                //        properties[cpt].SetValue(data, split[cpt]);
                //    }

                //    Requete requete = new Requete("INTERNAL", "EXTERNAL", log.nomTable, log.typeRequete, data);
                //    externe.AddLogRequest(requete);
            }

            foreach (ModificationLog log in externe.GetModificationLog())
            {
                var type = Type.GetType("marvel_sync.Models." + log.nomTable);
                object data = Activator.CreateInstance(type, log.newEntry);
                //object data = Assembly.GetExecutingAssembly().CreateInstance("marvel_sync.Models." + log.nomTable);

                //string[] split = log.newEntry.Split('|');
                //PropertyInfo[] properties = data.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
                //for (int cpt = 0; cpt < properties.Length; cpt++)
                //{
                //    properties[cpt].SetValue(data, split[cpt]);
                //}

                Requete requete = new Requete("EXTERNAL", "INTERNAL", log.nomTable, log.typeRequete, data);
                interne.AddLogRequete(requete);
            }
        }
    }
}

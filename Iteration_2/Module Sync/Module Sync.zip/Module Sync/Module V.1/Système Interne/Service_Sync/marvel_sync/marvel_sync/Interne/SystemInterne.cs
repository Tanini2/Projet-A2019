﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using marvel_sync.Models;
using marvel_sync.RessourceFiles;
using NLog;

namespace marvel_sync.Interne
{
    class SystemInterne
    {

        private static Logger Mysameplelogger = LogManager.GetCurrentClassLogger();

        private List<Requete> requeteSortie;
        private List<ModificationLog> modificationLog;
        private PrimaireDBContext dbContext;

        public SystemInterne()
        {
            dbContext = new PrimaireDBContext(InternalSys.SERVEUR_NAME, InternalSys.USERNAME, InternalSys.PASSWORD, InternalSys.DATABASE_NAME);
            requeteSortie = new List<Requete>();
        }

        public void GetInternalModification()
        {
            modificationLog = dbContext.GetModificationLog();
        }

        public List<ModificationLog> GetModificationLog()
        {
            return modificationLog;
        }

        public void SendRequestToInternalDB()
        {
            dbContext.SendRequestToInternalDb(requeteSortie);
        }

        public void AddLogRequete(Requete requete)
        {
            requeteSortie.Add(requete);
        }
    }
}

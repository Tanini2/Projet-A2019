﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace marvel_sync.Models
{
    [Serializable]
    class Etudiant : IComparable<Etudiant>
    {
        [Key]
        public string codePermanant { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public DateTime dateNaissance { get; set; }
        public string adresseMail { get; set; }

        public Etudiant(string codePermanant, string nom, string prenom, DateTime dateNaissance, string adresseMail)
        {
            this.codePermanant = codePermanant;
            this.nom = nom;
            this.prenom = prenom;
            this.dateNaissance = dateNaissance;
            this.adresseMail = adresseMail;
        }

        public Etudiant(string concatEntree)
        {
            string[] chaine = concatEntree.Split('|');

            codePermanant = chaine[0];
            nom = chaine[1];
            prenom = chaine[2];
            dateNaissance = Convert.ToDateTime(chaine[3]);
            adresseMail = chaine[4];
        }

        public Etudiant()
        {

        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as Etudiant);
        }
        
        public bool Equals(Etudiant other)
        {
            if (other == null)
                return false;

            return this.codePermanant.Equals(other.codePermanant) &&
                (
                    object.ReferenceEquals(this.codePermanant, other.codePermanant) ||
                    this.codePermanant != null &&
                    this.codePermanant.Equals(other.codePermanant)
                );
        }
        public string GetCodePermanant()
        {
            return codePermanant;
        }
        public string GetNom()
        {
            return nom;
        }
        public string GetPrenom()
        {
            return prenom;
        }
        public DateTime GetDateNaissance()
        {
            return GetDateNaissance();
        }
        public string GetAdresseMail()
        {
            return adresseMail;
        }
        public void SetCodePermanant()
        {

        }
        public int CompareTo(Etudiant other)
        {
            throw new NotImplementedException();
        }
    }
}


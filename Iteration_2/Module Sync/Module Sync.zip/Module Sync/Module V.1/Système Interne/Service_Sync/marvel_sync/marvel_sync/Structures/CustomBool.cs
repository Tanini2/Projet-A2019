﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marvel_sync.Structures
{   [Serializable]
    public struct CustomBool
    {
        public bool Value { get; set; }

        public static CustomBool Parse(string value)
        {
            return new CustomBool { Value = (value == "1" || value == "true") };
        }

        public override string ToString()
        {
            return Value.ToString(CultureInfo.InvariantCulture);
        }

        public static implicit operator bool(CustomBool lValue)
        {
            return lValue.Value;
        }
    }

}

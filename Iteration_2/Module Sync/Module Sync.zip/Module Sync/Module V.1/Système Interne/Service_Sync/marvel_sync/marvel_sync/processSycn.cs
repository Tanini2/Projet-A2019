﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using NLog.Fluent;

using marvel_sync.Externe;
using marvel_sync.Interne;

namespace marvel_sync
{

    class processSycn
    {

        private static Logger Mysameplelogger = LogManager.GetCurrentClassLogger();

        private DateTime tempsDebut;
        private DateTime tempsFin;

        private SystemInterne interne;
        private SystemExterne externe;

        private Comparateur comparateur;

        public processSycn()
        {
            PreparationProcess();          
        }

        public void Demarer()
        {
            tempsDebut = DateTime.Now;
            GetAllModificationLog();
            CompareData();
            SendDbRequest();
        }

        private void PreparationProcess()
        {
            Mysameplelogger.Trace("Création de l'instance du système de gestion Interne");
            interne = new SystemInterne();
            Mysameplelogger.Trace("Création de l'instance du système de gestion Externe");
            externe = new SystemExterne();
            
        }
        private void GetAllModificationLog()
        {
            Mysameplelogger.Trace("Obtention des log de modification des Bd");           
            interne.GetInternalModification();
            externe.GetExternalModificiationLog();
        }

        private void CompareData()
        {
            comparateur = new Comparateur(externe, interne);
        }

        private void SendDbRequest()
        {
            interne.SendRequestToInternalDB();
            externe.SendModificationRequest();
        }
    }
}

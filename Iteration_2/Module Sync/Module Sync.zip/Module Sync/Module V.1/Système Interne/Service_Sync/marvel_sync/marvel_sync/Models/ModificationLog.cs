﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marvel_sync.Models
{
    [Serializable]
    class ModificationLog
    {
        public int logId;
        public string nomTable { get; set; }
        public string typeRequete { get; set; }
        public DateTime dateEntree { get; set; }

        [JsonConverter(typeof(BoolConverter))]
        public bool validationRequete { get; set; }
        public string oldEntry { get; set; }
        public string newEntry { get; set; }

        public ModificationLog()
        {

        }

        public ModificationLog(int logId, string nomTable, string typeRequete, DateTime dateEntree, bool validationRequete, string oldEntry, string newEntry)
        {
            this.logId = logId;
            this.nomTable = nomTable;
            this.typeRequete = typeRequete;
            this.validationRequete = validationRequete;
            this.dateEntree = dateEntree;
            this.oldEntry = oldEntry;
            this.newEntry = newEntry;
        }
    }
}

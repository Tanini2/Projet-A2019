﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using marvel_sync.Models;
using Newtonsoft.Json;

using System.Resources;
using marvel_sync.RessourceFiles;
using NLog;
using System.IO;
using System.Runtime.Serialization.Json;

namespace marvel_sync.Externe
{
    class SystemExterne
    {
        private static Logger Mysameplelogger = LogManager.GetCurrentClassLogger();

        private List<Requete> requeteSortie;
        private List<ModificationLog> modificationLog;

        private static string ADRESSE_SERVEUR = ExternalSys.ADRESSE_SERVEUR;

        RequeteWeb connectionWeb;
        private string json_encoded;

        public SystemExterne()
        {
            requeteSortie = new List<Requete>();
            modificationLog = new List<ModificationLog>();
            connectionWeb = new RequeteWeb(ADRESSE_SERVEUR);
        }

        public void GetExternalModificiationLog()
        {
            ModificationLog[] tabLog;

            connectionWeb.GetExternalInformation();

            string jSon = connectionWeb.GetExternalInformation();
            JavaScriptSerializer js = new JavaScriptSerializer();

            try
            {
                tabLog = JsonConvert.DeserializeObject<ModificationLog[]>(jSon);

                foreach (ModificationLog log in tabLog)
                {
                    modificationLog.Add(log);
                }

            }
            catch(Exception exep)
            {
                Mysameplelogger.Error("Error: Erreur désérialisation JSON (" + exep.ToString() + ")");
            }                    
        }

        public void SendModificationRequest()
        {
            Requete[] requetes = requeteSortie.ToArray();
            JavaScriptSerializer js = new JavaScriptSerializer();

            var serializer = new JavaScriptSerializer();
            string jSon = serializer.Serialize(requetes);

            connectionWeb.UpdateExeternalSystem(jSon);
        }

        public void AddLogRequest(Requete requete)
        {
            requeteSortie.Add(requete);
        }

        public List<ModificationLog> GetModificationLog()
        {
            return modificationLog;
        }
    }
}

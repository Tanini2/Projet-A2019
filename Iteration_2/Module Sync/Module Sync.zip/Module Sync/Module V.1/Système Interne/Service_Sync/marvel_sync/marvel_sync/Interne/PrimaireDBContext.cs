﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using marvel_sync.Models;


namespace marvel_sync.Interne
{
    class PrimaireDBContext
    {
        string DB_CONNECTION_STRING;
        private SqlConnection ctn;

        public PrimaireDBContext(string serveurName, string username, string password, string bdName)
        {
            DB_CONNECTION_STRING = @"Data Source=" + serveurName + ";" + "Initial Catalog=" + bdName + ";" + "User id=" + username + ";" + "Password=" + password + ";";
        }
        public void ProccessToConnection()
        {
            try
            {
                ctn = new SqlConnection(DB_CONNECTION_STRING);
                ctn.Open();
                Console.WriteLine("Connection à la Bd réussi");
            }
            catch (SqlException)
            {
                Console.WriteLine("Erreur de connection à la Bd");
            }
        }
        public void ProccessToLogOut()
        {
            ctn.Close();
        }

        public List<ModificationLog> GetModificationLog()
        {
            List<ModificationLog> listeLog = new List<ModificationLog>();
            ModificationLog[] tableLog;
            ModificationLog log = new ModificationLog();

            ProccessToConnection();

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = ctn;

                cmd.CommandText = "SELECT * FROM ModificationLog;";
                
                IDataReader lecteur = cmd.ExecuteReader();
                while (lecteur.Read())
                {                  
                    log = new ModificationLog(lecteur.GetInt32(0), lecteur.GetString(1), lecteur.GetString(2), lecteur.GetDateTime(3), lecteur.GetBoolean(4), lecteur.GetString(5), lecteur.GetString(6));
                    listeLog.Add(log);
                }

                tableLog = new ModificationLog[listeLog.Count];
            }
            catch (SqlException sqle)
            {
                Console.WriteLine(sqle);
            }
            finally
            {
                ProccessToLogOut();
            }
            return listeLog;
        }

        public void SendRequestToInternalDb(List<Requete> requests)
        {
            foreach(Requete requete in requests)
            {
                requete.typeRequete = requete.typeRequete.ToUpper();
                if(requete.typeRequete == "UPDATE")
                {
                    UpdateDataTable(requete);
                }
                else if (requete.typeRequete == "INSERT")
                {
                    CreateDataTable(requete);
                }
                else if(requete.typeRequete == "DELETE")
                {
                    DeleteDataTable(requete);
                }
                else
                {
                    throw new Exception("Invalid SQL statement !");
                }
            }
        }

        // Délclaration du CRUD dynamique
        public void UpdateDataTable(Requete request)
        {
            ProccessToConnection();

            StringBuilder whereClause = new StringBuilder();
            StringBuilder setClause = new StringBuilder();
            PropertyInfo[] properties;
            SqlCommand cmd = new SqlCommand();
            object mObject;
    
            cmd.Connection = ctn;
            mObject = request.entree;
            properties = mObject.GetType().GetProperties(BindingFlags.Public| BindingFlags.Instance);

            cmd.CommandText = "UPDATE " + request.table;
       
            foreach (PropertyInfo propertyInfo in properties)
            {
                var attribute = Attribute.GetCustomAttribute(propertyInfo, typeof(KeyAttribute))
                    as KeyAttribute;

                if( attribute != null)
                {
                    whereClause.Append(" " + propertyInfo.Name + "=@" + propertyInfo.Name + ",");
                }
                else
                {
                    setClause.Append(" " + propertyInfo.Name + "=@" + propertyInfo.Name + ",");
                }
                cmd.Parameters.AddWithValue("@" + propertyInfo.Name, propertyInfo.GetValue(mObject, null).ToString());
            }

            whereClause.Remove(whereClause.Length - 1, 1);
            setClause.Remove(setClause.Length - 1, 1);

            cmd.CommandText += " SET" + setClause.ToString();
            cmd.CommandText += " WHERE" + whereClause.ToString() + ";";

            cmd.ExecuteNonQuery();

            cmd.CommandText = "";
            cmd.CommandText = "DELETE FROM ModificationLog;";
            cmd.ExecuteNonQuery();


            ProccessToLogOut();
        }

        private void DeleteDataTable(Requete request)
        {
            StringBuilder whereClause = new StringBuilder();
            PropertyInfo[] properties;
            SqlCommand cmd = new SqlCommand();
            object mObject;

            ProccessToConnection();

            cmd.Connection = ctn;
            mObject = request.entree;
            properties = mObject.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            cmd.CommandText = "DELETE FROM " + request.table;

            foreach (PropertyInfo propertyInfo in properties)
            {
                var attribute = Attribute.GetCustomAttribute(propertyInfo, typeof(KeyAttribute))
                    as KeyAttribute;

                if (attribute != null)
                {
                    whereClause.Append(" " + propertyInfo.Name + " = @" + propertyInfo.Name + ",");
                }               
                cmd.Parameters.AddWithValue("@" + propertyInfo.Name, propertyInfo.GetValue(mObject, null).ToString());
            }

            whereClause.Remove(whereClause.Length - 1, 1);

            cmd.CommandText += " WHERE " + whereClause.ToString();

            cmd.ExecuteNonQuery();

            cmd.CommandText = "";
            cmd.CommandText = "DELETE FROM ModificationLog;";
            cmd.ExecuteNonQuery();

            ProccessToLogOut();
        }

        private void CreateDataTable(Requete request)
        {
            StringBuilder valuesClause = new StringBuilder();
            StringBuilder fieldsClause = new StringBuilder();
            PropertyInfo[] properties;
            SqlCommand cmd = new SqlCommand();
            object mObject;

            ProccessToConnection();

            cmd.Connection = ctn;
            mObject = request.entree;
            properties = mObject.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            cmd.CommandText = "INSERT INTO " + request.table;

            foreach (PropertyInfo propertyInfo in properties)
            {              
                valuesClause.Append(" @" + propertyInfo.Name + ",");
                fieldsClause.Append(" " + propertyInfo.Name + ",");
                cmd.Parameters.AddWithValue("@" + propertyInfo.Name, propertyInfo.GetValue(mObject, null).ToString());

                Console.WriteLine("@" + propertyInfo.Name, propertyInfo.GetValue(mObject, null));

                var tst = propertyInfo.GetValue(mObject, null);
                string str = tst.ToString();
                Console.WriteLine(str);
            }

            valuesClause.Remove(valuesClause.Length - 1, 1);
            fieldsClause.Remove(fieldsClause.Length - 1, 1);

            cmd.CommandText += " (" + fieldsClause.ToString() + " )";
            cmd.CommandText += " VALUES (" + valuesClause.ToString() + ")";

            cmd.ExecuteNonQuery();

            cmd.CommandText = "";
            cmd.CommandText = "DELETE FROM ModificationLog;";
            cmd.ExecuteNonQuery();


            ProccessToLogOut();
        }
    }
}

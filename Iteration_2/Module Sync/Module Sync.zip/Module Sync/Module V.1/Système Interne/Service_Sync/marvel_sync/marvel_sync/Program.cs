﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using NLog.Fluent;

namespace marvel_sync
{
    class Program
    {
        private static Logger Mysameplelogger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            Mysameplelogger.Trace("Début du procéssus de synchronisation:");
            Mysameplelogger.Trace("----------------------------------------------------------------------------------------------------------------------------------------------");

            processSycn process = new processSycn();
            process.Demarer();
            
            Mysameplelogger.Trace("----------------------------------------------------------------------------------------------------------------------------------------------");
            Mysameplelogger.Trace("Fin du processus de synchronisation");

            //PrimaireDBContext context = new PrimaireDBContext("", "", "", "");
            //Etudiant etu = new Etudiant("dufn05079700", "Dufour", "Nicolas", DateTime.Now, "nicolas.duf@videotron.ca");
            //Requete requete = new Requete("", "", "Etudiant", "UPDATE", etu);
            //context.UpdateDataTable(requete);
           // Console.ReadKey(true);
        }
        static void LogSample()
        {

            Mysameplelogger.Trace("Trace: This is a sample TraceLog");
   
            Mysameplelogger.Debug("Debug: This is a sample DebugLog");
   
            Mysameplelogger.Info("Info: This is a sample Info Log");
            Mysameplelogger.Warn("Warn: This is a sample Warn Log");
            Mysameplelogger.Error("Error: This is a sample ErrorLog");
   
            Mysameplelogger.Fatal("Fatal: This is a sample Fatal ErrorLog");
   
            Mysameplelogger.Info()
               .Message("This is a test Info message '{0}'.",
                  DateTime.Now.Ticks)
               .Property("Test", "InfoWrite")
               .Write();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using Newtonsoft.Json;

using marvel_sync.RessourceFiles;
using NLog;

namespace marvel_sync.Externe
{
    class RequeteWeb
    {
        private static Logger Mysameplelogger = LogManager.GetCurrentClassLogger();

        private string adresseServeur;
        private static string typeContenue;
        private static string methodRequete;

        private HttpWebRequest requeteWeb;
        private HttpWebResponse reponseWeb;

        private Stream stream;


        public RequeteWeb(string adresseServeur)
        {
            typeContenue = "JSON";
            methodRequete = "POST";
            this.adresseServeur = adresseServeur;
        }

        public string UpdateExeternalSystem(string inputJSON)
        {
            string adresseConnection;
            string outputJSON = "";

            adresseConnection = adresseServeur + ExternalSys.UPDATE_EXTERNAL_SYSTEME;

            if (inputJSON != null)
            {
                requeteWeb = WebRequest.Create(adresseConnection) as HttpWebRequest;
                requeteWeb.ContentType = typeContenue;

                requeteWeb.Method = methodRequete;

                // Afficher le JSON en input.
                using (StreamWriter writer = new StreamWriter(requeteWeb.GetRequestStream()))
                {
                    writer.Write(inputJSON);
                }

                reponseWeb = requeteWeb.GetResponse() as HttpWebResponse;
                stream = reponseWeb.GetResponseStream();

                using (StreamReader reader = new StreamReader(stream))
                {
                    while (!reader.EndOfStream)
                    {
                        outputJSON += reader.ReadLine();
                    }
                }
            }
            else
            {
                throw new System.MissingMemberException("Membre manquant | Entrer un fichier JSON");
            }
            return outputJSON;
        }

        public string GetExternalInformation()
        {
            string adresseConnection;
            string outputJSON = "";

            adresseConnection = adresseServeur + ExternalSys.GET_EXTERNAL_DATA;
            using (var w = new WebClient())
            {                
                var json_data = string.Empty;
                try
                {
                    json_data = w.DownloadString(adresseConnection);
                    stream = reponseWeb.GetResponseStream();
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        while (!reader.EndOfStream)
                        {
                            outputJSON += reader.ReadLine();
                        }
                    }
                }
                catch (Exception exception)
                {
                    // à traiter.
                }
                finally
                {
                    outputJSON = json_data;
                    
                }
            }

            return outputJSON;
        }

        public string Post(string api_method, string api_data)
        {
            string result = "";

            using (WebClient wc = new WebClient())
            {
                byte[] bret = wc.UploadData(adresseServeur + ExternalSys.UPDATE_EXTERNAL_SYSTEME , "POST",
                  Encoding.UTF8.GetBytes("api_method=" + api_method + "&amp;api_data=" + api_data));
                result = Encoding.UTF8.GetString(bret);
            }

            return result;
        }
    }
}


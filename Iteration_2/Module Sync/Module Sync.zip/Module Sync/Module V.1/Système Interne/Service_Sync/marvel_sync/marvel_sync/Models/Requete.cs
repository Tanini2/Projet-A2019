﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marvel_sync.Models
{
    [Serializable]
    class Requete
    {
        public string systemSource { get; set; }
        public string systemDestination { get; set; }
        public string table { get; set; }
        public string typeRequete { get; set; }
        public object entree { get; set; }
       
        public Requete(string systemSource, string systemDestination, string table, string typeRequete, object entree)
        {
            this.systemSource = systemSource;
            this.systemDestination = systemDestination;
            this.table = table;
            this.typeRequete = typeRequete;
            this.entree = entree;
        }
    }
}

USE marvel_dev
GO

INSERT INTO dbo.Etudiant (codePermanant, nom, prenom, dateNaissance, adresseMail) VALUES ('DUFN1531439', 'Dufour', 'Nicolas', CURRENT_TIMESTAMP, 'nicolas.duf@videotron.ca'); 

SELECT *
FROM MOdificationLog;

SELECT *
FROM Etudiant;
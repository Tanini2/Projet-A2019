create database marvel_dev;


USE marvel_DEV
GO



INSERT INTO ModificationLog (nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry) VALUES ('Etudiant', 'INSERT', CURRENT_TIMESTAMP, 'true', '', 'Germain|Girard|05-07-2000');

CREATE TABLE ModificationLog(
    idLog             INT         IDENTITY(1,1) NOT NULL,
	nomTable          VARCHAR(20)               NOT NULL,
	typeRequete       VARCHAR(10)			    NOT NULL,
	dateEntree        DATETIME					NOT NULL,
	validationRequete BIT					    NULL,
	oldEntry          TEXT						NULL,
	newEntry          TEXT						NULL,
); 

SELECT *
FROM ModificationLog;
CREATE TABLE Etudiant(
    codePermanant VARCHAR(12),
	nom VARCHAR(60),
	prenom VARCHAR(60),
	dateNaissance dateTime,
	adresseMail VARCHAR(60),
	PRIMARY KEY (codePermanant)
);

CREATE TABLE NLogEntries (
  LogId   INT IDENTITY(1,1) PRIMARY KEY,
  Origine varchar(60),
  Message varchar(150),
  LogLevel VARCHAR (50),
  CreateOn Date,
  OrderId  INT
);

select *
from NLogEntries;



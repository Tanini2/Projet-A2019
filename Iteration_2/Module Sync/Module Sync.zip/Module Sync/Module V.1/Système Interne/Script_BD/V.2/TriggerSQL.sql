USE marvel_dev;
GO

DROP TRIGGER IF EXISTS insertLog;

CREATE TRIGGER insertLog ON Etudiant 
AFTER INSERT AS
		BEGIN
		DECLARE @codeperm AS VARCHAR(12)
		DECLARE @nom AS VARCHAR(60)
		DECLARE @pren AS VARCHAR(60)
		DECLARE @datenaiss AS datetime
		DECLARE @adresseemail AS VARCHAR(60)
		DECLARE cInserted CURSOR FOR
		SELECT codePermanant, nom, prenom, dateNaissance, adresseMail  FROM inserted;
		OPEN cInserted;
		FETCH cInserted INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
		WHILE (@@FETCH_STATUS=0) BEGIN
			INSERT INTO ModificationLog (nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry)
			VALUES ('Etudiant','Insert', Getdate(),0 , NULL, CONCAT( @codeperm, '|', @nom, '|', @pren, '|', @datenaiss, '|', @adresseemail));
			FETCH cInserted INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
		END;
		CLOSE cInserted;
		DEALLOCATE cInserted;	
	END;
--

INSERT INTO Etudiant VALUES('LESC15323906', 'Cedric', 'Lesperance', '' ,'cedric.lesperance@outlook.com')
--
SELECT * 
FROM ModificationLog
--
		
DROP TRIGGER IF EXISTS updateLog;
CREATE TRIGGER updateLog  ON Etudiant 
AFTER UPDATE AS
		BEGIN
		DECLARE @codeperm AS VARCHAR(12)
		DECLARE @nom AS VARCHAR(60)
		DECLARE @pren AS VARCHAR(60)
		DECLARE @datenaiss AS datetime
		DECLARE @adresseemail AS VARCHAR(60)
		DECLARE cUpdated CURSOR FOR
		SELECT codePermanant, nom, prenom, dateNaissance, adresseMail  FROM inserted;
		OPEN cUpdated;
		FETCH cUpdated INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
			WHILE (@@FETCH_STATUS=0) BEGIN
			INSERT INTO ModificationLog (nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry)
			VALUES ('Etudiant','Update', Getdate(),0 , NULL, CONCAT( @codeperm, '|', @nom, '|', @pren, '|', @datenaiss, '|', @adresseemail));
			FETCH cUpdated INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
		END;
		CLOSE cUpdated;
		DEALLOCATE cUpdated;	
	END;
--
DROP TRIGGER IF EXISTS deleteLog;
CREATE TRIGGER deleteLog  ON Etudiant 
AFTER DELETE AS
		BEGIN
		DECLARE @codeperm AS VARCHAR(12)
		DECLARE @nom AS VARCHAR(60)
		DECLARE @pren AS VARCHAR(60)
		DECLARE @datenaiss AS datetime
		DECLARE @adresseemail AS VARCHAR(60)
		DECLARE cUpdated CURSOR FOR
		SELECT codePermanant, nom, prenom, dateNaissance, adresseMail  FROM inserted;
		OPEN cDeleted;
		FETCH cDeleted INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
			WHILE (@@FETCH_STATUS=0) BEGIN
			INSERT INTO ModificationLog (nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry)
			VALUES ('Etudiant','Update', Getdate(),0 , NULL, CONCAT( @codeperm, '|', @nom, '|', @pren, '|', @datenaiss, '|', @adresseemail));
			FETCH cDeleted INTO @codeperm, @nom, @pren, @datenaiss, @adresseemail;
		END;
		CLOSE cDeleted;
		DEALLOCATE cDeleted;	
	END;
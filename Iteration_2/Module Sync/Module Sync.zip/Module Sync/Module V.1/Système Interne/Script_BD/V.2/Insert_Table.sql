USE marvel_dev
GO

INSERT INTO dbo.Etudiant (codePermanant, nom, prenom, dateNaissance, adresseMail) VALUES ('DUFN1531439', 'Dufour', 'Nicolas', CURRENT_TIMESTAMP, 'nicolas.duf@videotron.ca'); 

INSERT INTO ModificationLog (nomTable, typeRequete, dateEntree, validationRequete, oldEntry, newEntry) VALUES ('Etudiant', 'INSERT', CURRENT_TIMESTAMP, 'true', '', 'Germain|Girard|05-07-2000');
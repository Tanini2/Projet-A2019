create database marvel_dev;
USE marvel_dev

GO
--Cr�ation de la table �tudiant
IF OBJECT_ID(N'dbo.Etudiant', N'U') IS NOT NULL   
DROP TABLE dbo.Etudiant;
GO
CREATE TABLE Etudiant(
    codePermanant VARCHAR(12),
	nom VARCHAR(60),
	prenom VARCHAR(60),
	dateNaissance dateTime,
	adresseMail VARCHAR(60),
	PRIMARY KEY (codePermanant)
);
GO
--Cr�ation de la table NLog
GO
IF OBJECT_ID(N'dbo.NLogEntries', N'U') IS NOT NULL   
DROP TABLE dbo.NLogEntries;
GO
CREATE TABLE NLogEntries (
  LogId   INT IDENTITY(1,1) PRIMARY KEY,
  Origine varchar(60),
  Message varchar(150),
  LogLevel VARCHAR (50),
  CreateOn Date,
  OrderId  INT
);
--Cr�ation de la table ModificationLog
GO
IF OBJECT_ID(N'dbo.ModificationLog', N'U') IS NOT NULL   
DROP TABLE dbo.ModificationLog;
GO
CREATE TABLE ModificationLog(
    idLog             INT         IDENTITY(1,1) NOT NULL,
	nomTable          VARCHAR(20)               NOT NULL,
	typeRequete       VARCHAR(10)			    NOT NULL,
	dateEntree        DATETIME					NOT NULL,
	validationRequete BIT					    NULL,
	oldEntry          TEXT						NULL,
	newEntry          TEXT						NULL,
); 




<?php
// fonction donnée par microsoft qui permet de crée une SAS token hashé auquel azure relay va pouvoir communiquer
function generateSasToken($uri, $sasKeyName, $sasKeyValue) 
{ 
    $targetUri = strtolower(rawurlencode(strtolower($uri))); 
    $expires = time();     
    $expiresInMins = 60; 
    $week = 60*60*24*7;
    $expires = $expires + $week; 
    $toSign = $targetUri . "\n" . $expires; 
    $signature = rawurlencode(base64_encode(hash_hmac('sha256',             
    $toSign, $sasKeyValue, TRUE))); 
    $token = "SharedAccessSignature sr=" . $targetUri . "&sig=" . $signature . "&se=" . $expires .         "&skn=" . $sasKeyName; 
    return $token; 
    //la fonction retourne le token en string on auras a le passer dans le header de la requette post ou get
}

// fonction qui envoie le XML a azure relay via une requette post en utilisant CURL
function sendXML($XML) 
{ 
    // variale qui stocke le token en passant en parametre les inforation que le gerant de azure relay nous a fournis
    $KEY = generateSasToken('https://marvel-communication.servicebus.windows.net/primary-relay','RootManageSharedAccessKey','3VAszAoC+U7/gN1DyyWMj1MNy4dw1R+43XYNXxvhhlA=');
    
    $ch = curl_init('https://marvel-communication.servicebus.windows.net/primary-relay/');
    
    // Returns the data/output as a string instead of raw data
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    //Set your auth headers
    curl_setopt($ch, CURLOPT_POSTFIELDS, $XML);
    // header de la requette ou l'on passele token
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Cache-Control: no-cache, no-store, must-revalidate',
       'Content-Type: application/json',
       
       'Authorization:' . $KEY,
       'ContentType: application/atom+xml;type=entry;charset=utf-8'
       ));
    
    // get stringified data/output. See CURLOPT_RETURNTRANSFER
    $data = curl_exec($ch);
    // on recois le xml que le gerant azure relay nous a renvoyer et on le convertie en object Json
    $row = new SimpleXMLElement($data);
    $xmle = simplexml_load_string($data);
    $json_string = json_encode($xmle);    
    $result_array = json_decode($json_string, TRUE);
    print_r( $result_array);
   
   


    // information de la requette
    $info = curl_getinfo($ch);
    // fermeture de la requette
    curl_close($ch);
    
}

?>
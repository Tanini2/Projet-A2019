<?php
// Lien ver le fichier azure.php
include 'azure.php';
// assigner les donnée de la requette poste ajax dans des variables
$type = $_POST['type'] ;
$module = $_POST['module'] ;
$query = $_POST['query'] ;

// creation d'un xml avec les variable pour contruire la requette
$newsXML = new SimpleXMLElement("<news></news>");
$newsXML->addAttribute('REQUEST', 'GET');
$newsIntro = $newsXML->addChild('TYPE',$type);
$newsIntro = $newsXML->addChild('MODULE',$module);
$newsIntro = $newsXML->addChild('QUERY',$query);
Header('Content-type: text/xml');


// le xml est pret a etre envoyer au relay on appele la fonction sendXML qui se trouve dans azure.php
sendXML($newsXML);
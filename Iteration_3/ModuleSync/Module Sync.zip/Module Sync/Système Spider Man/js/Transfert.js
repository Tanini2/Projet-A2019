document.getElementById("Lootbox").addEventListener("click", function() {
  Threat('GET','LOOTBOX','GET_LOOTBOX')
}, false)


function Threat(Type,Module,Query) {
  $.ajax({
       type: "POST",
       url: './azure_relay/Process.php',
       data: {type: Type, module: Module, query: Query},
       success:function(data) { 
       alert(data)
      
       }

  });
}


<?php


echo '



<!DOCTYPE html>
<html>
<body>


                <center><input type="button" value="Bouton cliquer" id="Lootbox" width="280" height="125" > </center>
               
                 
                <script src="js/Transfert.js"></script>   
                <script src="https://code.jquery.com/jquery-3.4.1.js"></script>      
</body>
</html>





';
?>

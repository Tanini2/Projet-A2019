﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

using marvel_thor.RestAPITest.ModulesClass;

namespace marvel_thor.RestAPITest
{
    public class MainRequest
    {
        // à des fin de test nous avons ahouter la pertie permetant de traiter les requêtes dans ce système, normalement celui-ci devrait être dans le Système IronMan.
        // l'appel d'un API rest permet de traiter les requêtes.
        public XmlDocument InputRequest(XmlDocument inputXML)
        {
            XmlDocument outputXML = new XmlDocument();

            XmlNode requestType = inputXML.SelectSingleNode("//RequestType");
            XmlNode module = inputXML.SelectSingleNode("//ModuleName");

            outputXML = LootBox.GetLootBoxItems(inputXML);

            return outputXML;
        }
    }
}
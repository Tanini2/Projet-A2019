﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace marvel_thor.RestAPITest.ModulesClass
{
    public static class LootBox
    {
        public static XmlDocument GetLootBoxItems(XmlDocument inputXML)
        {
            List<string> lootBoxItems = new List<string> { "Carte Eau", "Courronne Impérial", "Épée de néan", "Armure de Kondor" };
            XmlDocument outpoutDocument = new XmlDocument();

            XmlNode docNode = outpoutDocument.CreateXmlDeclaration("1.0", "UTF-8\" standalone=\"yes", "");
            outpoutDocument.AppendChild(docNode);

            XmlNode rootNode = outpoutDocument.CreateElement("LootBoxItems");
            outpoutDocument.AppendChild(rootNode);

            for (int cpt = 0; cpt < lootBoxItems.Count; cpt++)
            {
                XmlNode itemNode = outpoutDocument.CreateElement("Item");
                XmlAttribute attribute = outpoutDocument.CreateAttribute("Id");
                attribute.Value = cpt.ToString();
                itemNode.Attributes.Append(attribute);
                itemNode.InnerText = lootBoxItems.ElementAt(cpt);
                rootNode.AppendChild(itemNode);
            }

            return outpoutDocument;
        }
    }
}
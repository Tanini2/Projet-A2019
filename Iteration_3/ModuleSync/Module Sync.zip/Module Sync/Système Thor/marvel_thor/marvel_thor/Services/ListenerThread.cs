﻿using Microsoft.Azure.Relay;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

using marvel_thor.RestAPITest;
using marvel_thor.Service;
using System.Xml;

namespace marvel_thor.Services
{
    // Class du Tread contenant le service de synchonisation. Cette classe hérite d'un extension de la classe thread qui wrappe les méthode de Thread. Cela dans le but de définir nos propres méthodes.
    public class ListenerThread : BaseThread
    {
        private string RelayNamespace;
        private string ConnectionName;
        private string KeyName;
        private string Key;
        
        private XmlDocument connectionInfo;

        private CancellationTokenSource source;
        private CancellationToken token;

        public ListenerThread() : base()
        {

            string ressourceValue;

            // Déclaration du token de cancellation
            source = new CancellationTokenSource();
            token = source.Token;

            // Obtenir les information de la connection hybride dans le fichier de resourrces.
            connectionInfo = new XmlDocument();

            ressourceValue = RelayConnection.ResourceManager.GetString("primary_relay");
            connectionInfo.LoadXml(ressourceValue);

            RelayNamespace = connectionInfo.DocumentElement.SelectSingleNode("/Relay/RelayNamespace").InnerText;
            ConnectionName = connectionInfo.DocumentElement.SelectSingleNode("/Relay/ConnectionName").InnerText;
            KeyName = connectionInfo.DocumentElement.SelectSingleNode("/Relay/KeyName").InnerText;
            Key = connectionInfo.DocumentElement.SelectSingleNode("/Relay/Key").InnerText;

        }
        public override void RunThread()
        { 
            // Initialisation du service de synchronisation.
            RunAsync(source).GetAwaiter().GetResult();
        }

        public void StopThread()
        {
            // Arrête du service de synchronisation
            source.Cancel();
            GlobalData.listenerLog.Add(new ListenerLog(DateTime.Now, "Sync Listener -> Event Handler: ConnectionClose", new List<LogData>() { new LogData("Statue", "Serveur en standby") }));
            Abort();
        }
        public void StartThread()
        {
            //Démarage du service de synchronisation
            Start();
            GlobalData.listenerLog.Add(new ListenerLog(DateTime.Now, "Sync Listener -> Event Handler: ConnectionOpen", new List<LogData>() { new LogData("Statue", "Serveur en écoute") }));
        }
        private async Task RunAsync(CancellationTokenSource cts)
        {
            // Service de synchronisation AsyncTask.

            var tokenProvider = TokenProvider.CreateSharedAccessSignatureTokenProvider(KeyName, Key);
            var listener = new HybridConnectionListener(new Uri(string.Format("sb://{0}/{1}", RelayNamespace, ConnectionName)), tokenProvider);

            cts.Token.Register(() => listener.CloseAsync(CancellationToken.None));

            // Définition des statues des événements
            listener.Connecting += (o, e) => { Console.WriteLine("Connecting"); };
            listener.Offline += (o, e) => { Console.WriteLine("Offline"); };
            listener.Online += (o, e) => { Console.WriteLine("Online"); };

            // Obtention du HTTP request Hnadler.
            listener.RequestHandler = (context) =>
            {

                string stringXml;
                bool errorHandler = false;

                XmlDocument xmlInputDocument = new XmlDocument();
                XmlDocument xmlOutputDocument = new XmlDocument();

                // Réception du XML appel de l'interface de IronMan
                using (Stream receiveStream = context.Request.InputStream)
                {
                    using (StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8))
                    {
                        stringXml = readStream.ReadToEnd();
                    }
                }

                try
                {
                    xmlInputDocument.LoadXml(stringXml);
                }
                catch (XmlException exception)
                {
                    errorHandler = true;
                    //Invalid XML
                }

                if (!errorHandler)
                {
                    MainRequest request = new MainRequest();
                    xmlOutputDocument = request.InputRequest(xmlInputDocument);
                }

                // Traitement du context.Request.Url, HttpMethod, Headers, InputStream...
                context.Response.StatusCode = HttpStatusCode.OK;
                context.Response.StatusDescription = "OK";

                // Renvoi de la réponce de la requête
                using (var sw = new StreamWriter(context.Response.OutputStream))
                {
                    //string requestString = HttpUtility.UrlPathEncode("idata=" + xmlOutputDocument); //XMLDoc is the XML data string being submitted.

                    sw.WriteLine(xmlOutputDocument.InnerXml);
                    GlobalData.listenerLog.Add(new ListenerLog(DateTime.Now, "Sync Listener -> Event Handler: Inbound HTTP GET Request", new List<LogData>() { new LogData("Input Data", stringXml), new LogData("Output Data", xmlOutputDocument.InnerXml) }));
                }
            };

            await listener.OpenAsync();

            await Console.In.ReadLineAsync();

            // Fermeture du listener à la fin du procéssus d'écoute
            await listener.CloseAsync();
            

            await listener.CloseAsync(token);
          
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace marvel_thor.Services
{
    public class LogData
    {
        public string description;
        public string data;

        public LogData(string description, string data)
        {
            this.description = description;
            this.data = data;
        }

    }
}
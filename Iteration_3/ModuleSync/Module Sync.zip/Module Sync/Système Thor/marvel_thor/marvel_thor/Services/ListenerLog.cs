﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace marvel_thor.Services
{
    public class ListenerLog
    {
        public DateTime dateTime;

        public List<LogData> data;

        public string requestDescription;

        public ListenerLog(DateTime dateTime, string requestDescription, List<LogData> data)
        {
            this.dateTime = dateTime;
            this.data = data;
            this.requestDescription = requestDescription;
        }
    }
}
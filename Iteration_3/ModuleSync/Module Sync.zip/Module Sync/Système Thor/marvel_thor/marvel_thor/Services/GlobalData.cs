﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using marvel_thor.Services;

namespace marvel_thor.Service

{
    public static class GlobalData
    {
        // Classe statique comprenant les différentes composante devant être accessible pour l'ensemble du programme, aucune sécurité de lock d'object n'a encore été mise en place.

       
        // Token de cancellation permettant d'arrêter le service Sync
       // public static CancellationToken cancellationToken { get; set; }

        // Thread contenant le service de synchronisation
        public static ListenerThread primarySyncProcess { get; set; }

        // Variable permmettant de logger de l'information d'une session, solution temporaire.
        public static List<ListenerLog> listenerLog { get; set; }

    }
}
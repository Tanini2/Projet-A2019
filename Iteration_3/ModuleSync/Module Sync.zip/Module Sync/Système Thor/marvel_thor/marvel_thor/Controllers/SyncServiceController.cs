﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Azure.Relay;

using marvel_thor.Service;

using marvel_thor.Services;
using System.Threading;

namespace marvel_thor.Controllers
{
    public class SyncServiceController : Controller
    {
        // GET: SyncService
        public ActionResult Index()
        {
            if (GlobalData.primarySyncProcess == null)
            {
                ViewBag.Msg = "ARRET";
            }
            else if (GlobalData.primarySyncProcess.IsAlive)
            {
                ViewBag.Msg = "MARCHE";
            }
            else
            {
                ViewBag.Msg = "ARRET";
            }

            List<ListenerLog> log = new List<ListenerLog>();
            log = GlobalData.listenerLog;

            ViewBag.Message = "Gestionnaire: Service Sync";

            return View(log);
        }

        [HttpPost]
        public ActionResult ProcessForm(string submit)
        {
            switch (submit)
            {
                case "MARCHE":
                    // Valider que le Thread n'est pas en cours d'exécution avant de démarer une nouveau.
                    if (GlobalData.primarySyncProcess == null)
                    {
                        GlobalData.primarySyncProcess = new ListenerThread();
                        GlobalData.primarySyncProcess.StartThread();
                    }
                    else if(!GlobalData.primarySyncProcess.IsAlive)
                    {
                        GlobalData.primarySyncProcess = new ListenerThread();
                        GlobalData.primarySyncProcess.StartThread();
                    }
                    break;
                case "ARRET":
                    if (GlobalData.primarySyncProcess.IsAlive)
                    {
                        GlobalData.primarySyncProcess.StopThread();

                        Thread.Sleep(200);
                    }
                    break;
                case "Refresh":
                    break;
                case "Reset":
                    GlobalData.listenerLog.Clear();
                    break;
            }

            if (GlobalData.primarySyncProcess == null)
            {
                ViewBag.Msg = "ARRET";
            }
            else if (GlobalData.primarySyncProcess.IsAlive)
            {
                ViewBag.Msg = "MARCHE";
            }
            else
            {
                ViewBag.Msg = "ARRET";
            }

            ViewBag.Message = "Gestionnaire: Service Sync";

            List<ListenerLog> log = new List<ListenerLog>();
            log = GlobalData.listenerLog;

            return View("Index", log);
        }
    }
}